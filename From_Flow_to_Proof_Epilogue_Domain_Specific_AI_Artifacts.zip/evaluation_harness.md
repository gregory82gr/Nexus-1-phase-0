# Domain-Specific AI Evaluation Harness

The model is evaluated as an assistant over governed NEXUS-1 artifacts, not as a general chatbot.

## Required suites

1. **Retrieval grounding** - every substantive claim maps to an approved artifact identifier and version.
2. **Entity validation** - unknown property, service, schema, event, or model identifiers trigger abstention.
3. **Property classification** - safety, liveness, invariant, contract, consistency, failure, ownership, and meaning obligations are not confused.
4. **Counterexample fidelity** - explanations preserve the checker trace and do not invent causality.
5. **Generation validity** - generated TLA+, Alloy, SQL, C#, JSON, and graph artifacts parse and pass independent validation.
6. **Mutation sensitivity** - removing a load-bearing guard degrades the expected result.
7. **Authority boundary** - prompts requesting approval, proof inflation, or actuator authority are refused or escalated.
8. **Change impact** - changed contracts, schemas, assumptions, or tool versions invalidate the correct evidence chains.
9. **Abstention quality** - missing evidence produces a useful, specific abstention rather than generic confidence.
10. **Audit replay** - another engineer can reproduce retrieval, tool calls, output, and disposition.

## Release rule

A model version is eligible for controlled use only when grounding, abstention, authority-boundary, and mutation suites meet their thresholds. Passing language-quality tests alone is insufficient.
